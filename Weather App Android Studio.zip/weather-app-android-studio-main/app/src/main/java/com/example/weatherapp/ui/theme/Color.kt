package com.example.weatherapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFcae718)
val PurpleGrey80 = Color(0xFFcae718)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF2DD273)
val PurpleGrey40 = Color(0xFF2DD273)
val Pink40 = Color(0xFF7D5260)